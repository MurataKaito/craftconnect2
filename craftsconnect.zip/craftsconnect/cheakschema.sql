-- 'CraftsConnect' スキーマ内のテーブル一覧を取得
SELECT *
FROM information_schema.tables
WHERE table_schema = 'CraftsConnect'
ORDER BY table_name;

-- 'Ideas' テーブルの列構造を確認
SELECT *
FROM information_schema.columns
WHERE table_schema = 'CraftsConnect'
  AND table_name = 'Ideas2';




-- 'Ideas' テーブルにサンプルデータを挿入
INSERT INTO CraftsConnect.Ideas2 (IdeaId, IdeaName, IdeaConcept, IdeaDate, IdeaTechnology1, IdeaTechnology2, IdeaTechnology3,IdeaTechnology4)
VALUES (1, N'革新的な製品', N'この製品は市場を変える可能性がある。', GETDATE(), N'AI', N'ロボティクス', N'ビッグデータ');

-- 挿入したデータの確認
SELECT * FROM CraftsConnect.Ideas;


