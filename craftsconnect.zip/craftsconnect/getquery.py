import pyodbc

# 接続情報
server = 'craftsconnect.database.windows.net'
database = 'craftsconnect'
username = 'crafts_connect_admin'
password = 'Bemaker0415'
driver= '{ODBC Driver 18 for SQL Server}'

try:
    conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};PORT=1433;DATABASE={database};UID={username};PWD={password}')
except pyodbc.Error as e:
    print("Error in connection:", e)

# カーソルの作成
cursor = conn.cursor()

# Ideas テーブルから全データの取得
cursor.execute("SELECT * FROM users")

# データの表示
rows = cursor.fetchall()
for row in rows:
    print(row)

# 接続のクローズ
cursor.close()
conn.close()
