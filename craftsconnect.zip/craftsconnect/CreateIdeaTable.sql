-- 'Ideas2' テーブルにサンプルデータを挿入
INSERT INTO Ideas2 (IdeaId, IdeaName, IdeaConcept, IdeaDate, IdeaTechnology1, IdeaTechnology2, IdeaTechnology3)
VALUES (1, N'革新的な製品', N'この製品は市場を変える可能性がある。', GETDATE(), N'AI', N'ロボティクス', N'ビッグデータ');

-- 挿入したデータの確認
SELECT * FROM Ideas2;
